-- 2. CRUD Operations to Manage Music Content and Artist Information

-- INSERT (Create)
INSERT INTO artists (name, country, bio) 
VALUES ('Daft Punk', 'France', 'Electronic music duo');

INSERT INTO artists (name, country, bio) 
VALUES ('Queen', 'UK', 'Rock band');

INSERT INTO genres (name) VALUES ('Electronic');
INSERT INTO genres (name) VALUES ('Rock');

INSERT INTO albums (title, artist_id, release_year) 
VALUES ('Discovery', 1, 2001);

INSERT INTO tracks (title, album_id, artist_id, genre_id, duration_seconds, play_count) 
VALUES ('One More Time', 1, 1, 1, 320, 1500000);

INSERT INTO tracks (title, album_id, artist_id, genre_id, duration_seconds, play_count) 
VALUES ('Aerodynamic', 1, 1, 1, 212, 850000);

COMMIT;

-- SELECT (Read)
SELECT 
    t.track_id, 
    t.title AS track_title, 
    a.name AS artist_name, 
    al.title AS album_title, 
    g.name AS genre, 
    t.duration_seconds, 
    t.play_count
FROM tracks t
JOIN artists a ON t.artist_id = a.artist_id
LEFT JOIN albums al ON t.album_id = al.album_id
LEFT JOIN genres g ON t.genre_id = g.genre_id
WHERE t.track_id = 1;

-- UPDATE (Update)
UPDATE artists 
SET bio = 'Legendary French electronic music duo formed in Paris.' 
WHERE artist_id = 1;

UPDATE tracks 
SET play_count = play_count + 1 
WHERE track_id = 1;

COMMIT;

-- DELETE (Delete)
DELETE FROM tracks 
WHERE track_id = 1;

DELETE FROM artists 
WHERE artist_id = 1;

COMMIT;
