-- 1. Create Schema and Relational Tables
-- Target: Oracle Database 12c/19c/21c/23c

-- 1. Artists Table
CREATE TABLE artists (
    artist_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR2(255) NOT NULL,
    country VARCHAR2(100),
    bio CLOB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Genres Table
CREATE TABLE genres (
    genre_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR2(100) NOT NULL UNIQUE
);

-- 3. Albums Table
CREATE TABLE albums (
    album_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    title VARCHAR2(255) NOT NULL,
    artist_id NUMBER NOT NULL,
    release_year NUMBER(4),
    CONSTRAINT fk_albums_artist FOREIGN KEY (artist_id) REFERENCES artists(artist_id) ON DELETE CASCADE
);

-- 4. Tracks Table
CREATE TABLE tracks (
    track_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    title VARCHAR2(255) NOT NULL,
    album_id NUMBER,
    artist_id NUMBER NOT NULL,
    genre_id NUMBER,
    duration_seconds NUMBER NOT NULL,
    play_count NUMBER DEFAULT 0,
    CONSTRAINT fk_tracks_album FOREIGN KEY (album_id) REFERENCES albums(album_id) ON DELETE SET NULL,
    CONSTRAINT fk_tracks_artist FOREIGN KEY (artist_id) REFERENCES artists(artist_id) ON DELETE CASCADE,
    CONSTRAINT fk_tracks_genre FOREIGN KEY (genre_id) REFERENCES genres(genre_id) ON DELETE SET NULL
);

-- 5. Playlists Table
CREATE TABLE playlists (
    playlist_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id NUMBER NOT NULL,
    name VARCHAR2(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. Playlist Tracks (Junction Table)
CREATE TABLE playlist_tracks (
    playlist_id NUMBER NOT NULL,
    track_id NUMBER NOT NULL,
    position NUMBER NOT NULL,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_playlist_tracks PRIMARY KEY (playlist_id, track_id),
    CONSTRAINT fk_pt_playlist FOREIGN KEY (playlist_id) REFERENCES playlists(playlist_id) ON DELETE CASCADE,
    CONSTRAINT fk_pt_track FOREIGN KEY (track_id) REFERENCES tracks(track_id) ON DELETE CASCADE
);

-- 7. Listening History Table
CREATE TABLE listening_history (
    history_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id NUMBER NOT NULL,
    track_id NUMBER NOT NULL,
    played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_lh_track FOREIGN KEY (track_id) REFERENCES tracks(track_id) ON DELETE CASCADE
);
