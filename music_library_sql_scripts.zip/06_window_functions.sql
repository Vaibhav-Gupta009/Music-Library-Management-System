-- 6. Analytical Window Functions

-- 1. Top 5 tracks per genre by play count using DENSE_RANK()
WITH RankedTracks AS (
    SELECT 
        t.track_id,
        t.title AS track_title,
        g.name AS genre_name,
        t.play_count,
        DENSE_RANK() OVER (
            PARTITION BY t.genre_id 
            ORDER BY t.play_count DESC
        ) AS genre_rank
    FROM tracks t
    JOIN genres g ON t.genre_id = g.genre_id
)
SELECT track_title, genre_name, play_count, genre_rank
FROM RankedTracks
WHERE genre_rank <= 5;

-- 2. Next track played in user listening history using LEAD()
SELECT 
    history_id,
    user_id,
    played_at,
    track_id AS current_track_id,
    LEAD(track_id, 1) OVER (
        PARTITION BY user_id 
        ORDER BY played_at ASC
    ) AS next_track_id,
    LEAD(played_at, 1) OVER (
        PARTITION BY user_id 
        ORDER BY played_at ASC
    ) AS next_played_at
FROM listening_history;

-- 3. Running total of plays per day
WITH DailyPlays AS (
    SELECT 
        TRUNC(played_at) AS play_date,
        COUNT(*) AS daily_play_count
    FROM listening_history
    GROUP BY TRUNC(played_at)
)
SELECT 
    play_date,
    daily_play_count,
    SUM(daily_play_count) OVER (
        ORDER BY play_date ASC 
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS running_total_plays
FROM DailyPlays;

-- 4. Track contribution percentage to album total plays using SUM() OVER (PARTITION BY album_id)
SELECT 
    t.track_id,
    t.title AS track_title,
    al.title AS album_title,
    t.play_count AS track_plays,
    SUM(t.play_count) OVER (PARTITION BY t.album_id) AS album_total_plays,
    ROUND(
        (t.play_count * 100) / NULLIF(SUM(t.play_count) OVER (PARTITION BY t.album_id), 0), 
        2
    ) AS contribution_percentage
FROM tracks t
JOIN albums al ON t.album_id = al.album_id;
