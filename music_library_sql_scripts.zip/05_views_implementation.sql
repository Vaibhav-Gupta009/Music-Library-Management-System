-- 5. Views: Track Details View and Top Artists Aggregation View

-- Track details view joining tracks, albums, artists, and genres
CREATE OR REPLACE VIEW view_track_details AS
SELECT 
    t.track_id,
    t.title AS track_title,
    t.duration_seconds,
    t.play_count,
    al.title AS album_title,
    al.release_year,
    a.name AS artist_name,
    g.name AS genre_name
FROM tracks t
JOIN artists a ON t.artist_id = a.artist_id
LEFT JOIN albums al ON t.album_id = al.album_id
LEFT JOIN genres g ON t.genre_id = g.genre_id;

-- Top artists view based on play counts
CREATE OR REPLACE VIEW view_top_artists AS
SELECT 
    a.artist_id,
    a.name AS artist_name,
    NVL(SUM(t.play_count), 0) AS total_plays,
    COUNT(t.track_id) AS total_tracks
FROM artists a
JOIN tracks t ON a.artist_id = t.artist_id
GROUP BY a.artist_id, a.name
ORDER BY total_plays DESC;

-- Simplified song-search query utilizing the view
SELECT track_title, artist_name, album_title 
FROM view_track_details 
WHERE genre_name = 'Electronic' AND release_year >= 2000;
