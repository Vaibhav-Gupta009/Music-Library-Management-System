-- 3. Search Songs, Manage Playlists, and Analyze Music Preferences

-- Search for songs by title, artist, or genre (case-insensitive)
SELECT 
    t.track_id, 
    t.title AS track_title, 
    a.name AS artist_name, 
    g.name AS genre_name
FROM tracks t
JOIN artists a ON t.artist_id = a.artist_id
LEFT JOIN genres g ON t.genre_id = g.genre_id
WHERE LOWER(t.title) LIKE '%time%' 
   OR LOWER(a.name) LIKE '%daft%' 
   OR LOWER(g.name) LIKE '%elec%';

-- Create playlists and add tracks with position sequence
INSERT INTO playlists (user_id, name) 
VALUES (101, 'My Synthwave Mix');

INSERT INTO playlist_tracks (playlist_id, track_id, position) 
VALUES (1, 1, 1);

INSERT INTO playlist_tracks (playlist_id, track_id, position) 
VALUES (1, 2, 2);

COMMIT;

-- Analyze user music preferences (Favorite genres by listen count)
SELECT 
    g.name AS genre, 
    COUNT(h.history_id) AS total_plays
FROM listening_history h
JOIN tracks t ON h.track_id = t.track_id
JOIN genres g ON t.genre_id = g.genre_id
WHERE h.user_id = 101
GROUP BY g.genre_id, g.name
ORDER BY total_plays DESC;
