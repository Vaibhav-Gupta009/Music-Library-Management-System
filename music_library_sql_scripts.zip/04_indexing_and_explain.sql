-- 4. Indexing: Composite, B-Tree, and FULLTEXT (Oracle Text) Comparison

-- 1. Composite index on playlist_tracks (playlist_id, position)
CREATE INDEX idx_playlist_position ON playlist_tracks (playlist_id, position);

-- 2. Regular B-Tree index on title for prefix search testing
CREATE INDEX idx_track_title ON tracks(title);

-- 3. Oracle Text (FULLTEXT) index on tracks(title) and artists(name)
CREATE INDEX idx_ft_track_title ON tracks(title) INDEXTYPE IS CTXSYS.CONTEXT;
CREATE INDEX idx_ft_artist_name ON artists(name) INDEXTYPE IS CTXSYS.CONTEXT;

-- Query 1: Leading Wildcard Search (LIKE '%text%') -> Table Access Full
EXPLAIN PLAN FOR 
SELECT * FROM tracks WHERE title LIKE '%Time%';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY());

-- Query 2: Prefix Search (LIKE 'text%') -> Index Range Scan
EXPLAIN PLAN FOR 
SELECT * FROM tracks WHERE title LIKE 'Time%';

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY());

-- Query 3: FULLTEXT Search (CONTAINS) -> Domain Index Scan
EXPLAIN PLAN FOR 
SELECT * FROM tracks WHERE CONTAINS(title, 'Time') > 0;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY());
